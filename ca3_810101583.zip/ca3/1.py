
import matplotlib.pyplot as plt
import random
import tensorflow as tf
from keras.datasets import mnist
(_, _) , (test_images, _) = mnist.load_data()
test_images = test_images.reshape(test_images.shape[0], -1)
test_images = test_images.astype('float32') / 255.0
autoencoder = tf.keras.models.load_model("mnist_AE.h5")
reconstructed_images = autoencoder.predict(test_images)
n = 4
plt.figure(figsize=(20, 4))
for i in range(n):
    ax = plt.subplot(2, n, i + 1)
    rand_num = random.randint(0, len(test_images) - 1)
    plt.imshow(test_images[rand_num].reshape(28, 28))

    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)

    ax = plt.subplot(2, n, i + 1 + n)
    plt.imshow(reconstructed_images[rand_num].reshape(28, 28))

    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    print("i:  ", rand_num)
plt.show()


import numpy as np
def calc_mse(org, recons):
    error = org - recons
    mse = np.mean(np.square(error))
    return mse
mse_values = []
for i in range(len(test_images)):
    mse = calc_mse(test_images[i], reconstructed_images[i])
    mse_values.append(mse)

plt.hist(mse_values, bins=30, edgecolor='black', color='navy')
plt.xlabel('MSE Values')
plt.ylabel('Frequency')
plt.title('Histogram of MSE Values')
plt.show()

mean_mse = np.mean(mse_values)
std_mse = np.std(mse_values)

from scipy import stats
ks_statistic, p_value = stats.kstest(mse_values, cdf='norm', args=(mean_mse, std_mse))


print(f"p_value:  {p_value}")
if p_value * 100 > 5:
    print(f"We can accept that the datas(the mse values) are a normal distribution with the parameters  mean={mean_mse} ,  std={std_mse}")
else:
    print("The assumption is rejected, thus the mse's aren't a normal distribution")