import numpy as np
import random
import pandas as pd
import matplotlib.pyplot as plt
file_path = 'FIFA2020.csv'
df = pd.read_csv(file_path, encoding = "ISO-8859-1")
def set_seed(seed):
    np.random.seed(seed)
    random.seed(seed)

set_seed(810109203)
randoms_weight = np.array(random.sample(df['weight'].tolist(), 100))

weight_mean = randoms_weight.mean()
weight_var = randoms_weight.var()
weight_std = randoms_weight.std()

print("Mean(average): ", weight_mean)
print("Variance: ", weight_var)
print("Standard deviation: ", weight_std)
import scipy.stats as stats


# Q-Q plot
stats.probplot(randoms_weight, dist="norm", sparams=(weight_mean, weight_std), plot=plt)
plt.title('Q-Q Plot')
plt.xlabel('Theoretical quantiles')
plt.ylabel('sample quantiles')
plt.show()
import scipy.stats as stats
statistic, p_value = stats.shapiro(randoms_weight)

print("p_value: ", p_value)
if p_value > 0.05:
    print("We can't reject the null hypophesis, in this case it means the weight of the players is a normal distribution")
else:
    print("We reject the null hypophesis, so in this case the weight of the players doesn't follow a normal distribution")
    
    
    
    
def _3(n: int):
  randoms_weight = np.array(random.sample(df['weight'].tolist(), n))

  weight_mean = randoms_weight.mean()
  weight_var = randoms_weight.var()
  weight_std = randoms_weight.std()

  print("Mean(average): ", weight_mean)
  print("Variance: ", weight_var)
  print("Standard deviation: ", weight_std)


  import scipy.stats as stats


  # Q-Q plot
  stats.probplot(randoms_weight, dist="norm", sparams=(weight_mean, weight_std), plot=plt)
  plt.title('Q-Q Plot')
  plt.xlabel('Theoretical quantiles')
  plt.ylabel('sample quantiles')
  plt.show()


  import scipy.stats as stats
  statistic, p_value = stats.shapiro(randoms_weight)

  print("p_value: ", p_value)
  if p_value > 0.05:
      print("We can't reject the null hypophesis, in this case it means the weight of the players is a normal distribution")
  else:
      print("We reject the null hypophesis, so in this case the weight of the players doesn't follow a normal distribution")
      
      
_3(500)
_3(2000)


def test_normal(n: int):
  samples = np.random.poisson(lam=3, size=n)

  sample_mean = samples.mean()
  sample_std = samples.std()

  import scipy.stats as stats


  # Q-Q plot
  stats.probplot(samples, dist="norm", sparams=(sample_mean, sample_std), plot=plt)
  plt.title('Q-Q Plot')
  plt.xlabel('Theoretical quantiles')
  plt.ylabel('sample quantiles')
  plt.show()


  statistic, p_value = stats.shapiro(samples)

  print("p_value: ", p_value)
  if p_value > 0.05:
      print(f"We can't reject the null hypophesis, in this case it means the {n} samples of the poisson distribution can be counted as a normal distribution")
  else:
      print("We reject the null hypophesis, so in this case it means the {n} samples of the poisson distribution can't be counted as a normal distribution")
      
test_normal(n=5)
test_normal(n=50)
test_normal(n=5000)
