import pandas as pd
file_path = 'FIFA2020.csv'
df = pd.read_csv(file_path, encoding = "ISO-8859-1")
mean_dribbling = int(df['dribbling'].mean())
mean_pace = int(df['pace'].mean())

# Replace None values with the mean
df['dribbling'].fillna(mean_dribbling, inplace=True)
df['pace'].fillna(mean_pace, inplace=True)

print(df.loc[8, 'dribbling'])
print(df.loc[9, 'dribbling'])
print(df.loc[10, 'dribbling'])
print(df.head())
max_age = df['age'].max()
min_age = df['age'].min()

q1_age = df['age'].quantile(1/4)
q2_age = df['age'].quantile(1/2)  # Median
q3_age = df['age'].quantile(3/4)

palyer_name_max_age = df.loc[df['age'] == max_age, 'player_extended_name'].values[0]
palyer_name_min_age = df.loc[df['age'] == min_age, 'player_extended_name'].values[0]

print("Player_name:", palyer_name_max_age, "  Max age:", max_age)
print("Player_name:", palyer_name_min_age, "  Min age:", min_age)
print("First quartile (Q1):", q1_age)
print("Second quartile (Q2 - Median):", q2_age)
print("Third quartile (Q3):", q3_age)
import matplotlib.pyplot as plt

plt.boxplot(df['age'])
plt.ylabel('age')

# Annotations
plt.text(1.1, q1_age, f'Q1: {q1_age}', va='center', ha='left')
plt.text(1.1, q2_age, f'Q2: {q2_age}', va='center', ha='left')
plt.text(1.1, q3_age, f'Q3: {q3_age}', va='center', ha='left')
plt.text(1.1, min_age, f'Min: {min_age}', va='center', ha='left')
plt.text(1.1, max_age, f'Max: {max_age}', va='center', ha='left')

plt.show()