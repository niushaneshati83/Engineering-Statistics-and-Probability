import numpy as np
import matplotlib.pyplot as plt
# Original data(#1)
x_original = np.array([-2.3, -1.1, 0.5, 3.2, 4.0, 6.7, 10.3, 11.5])
y_original = np.array([-9.6, -4.9, -4.1, 2.7, 5.9, 10.8, 18.9, 20.5])

# outlier
x_outlier = np.array([5.8, 20.4])
y_outlier = np.array([31.3, 14.1])

# leverage point
x_leverage = np.array([20.4])
y_leverage = np.array([31.3])

# Data with outlier(#2)
x_data_with_outlier = np.concatenate((x_original, x_outlier), axis=None)
y_data_with_outlier = np.concatenate((y_original, y_outlier), axis=None)

# Data with leverage point(#3)
x_data_with_leverage = np.concatenate((x_original, x_leverage), axis=None)
y_data_with_leverage = np.concatenate((y_original, y_leverage), axis=None)

# Data with both outlier and leverage point(#4)
x_both = np.concatenate((x_original, x_outlier, x_leverage), axis=None)
y_both = np.concatenate((y_original, y_outlier, y_leverage), axis=None)
all_4_cases = [
    (x_original, y_original, "Original Data"),
    (x_data_with_outlier , y_data_with_outlier, "Original Data + Outlier"),
    (x_data_with_leverage , y_data_with_leverage, "Original Data + Leverage point"),
    (x_both, y_both, "Original Data + Outlier + Leverage Point")
]
def linear_regression(x, y):
  x_mean = np.mean(x)
  y_mean = np.mean(y)

  numerator = np.sum((x - x_mean) * (y - y_mean))
  denominator = np.sum((x - x_mean)**2)

  slope = numerator / denominator
  intercept = y_mean - slope * x_mean

  # R^2
  y_hat = slope * x + intercept
  sst = np.sum((y - y_mean)**2)
  sse = np.sum((y_hat - y)**2)
  r_squared = 1 - sse / sst

  return slope, intercept, r_squared
for x, y, title in all_4_cases:
    print(title)
    slope, intercept, r_squared = linear_regression(x, y)

    # Plot the scatter plot
    plt.scatter(x, y)

    # Plot the regression line
    plt.plot(x, slope * x + intercept, label="R^2 = {:.2f}".format(r_squared))

    plt.title(title)
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.legend()
    plt.show()
    print()
    print()
    print()
    