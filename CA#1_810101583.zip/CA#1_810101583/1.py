import numpy as np 
import matplotlib.pyplot as plt
def binomial(n,m,p):
    x=np.random.choice([0,1],size=(n,m),p=[1-p,p])
    y = np.sum(x,axis=0)
    return y
e_amali={}
e_theory={}
var_amali={}
var_theory={}
list_e_amali=[]
list_e_theory=[]
list_var_amali=[]
list_var_theory=[]
for p in range(100):
    sum = 0 
    e=0
    n=500
    m=5000
    bino=binomial(n,m,p/100)
    sum=np.sum(bino)
    e_amal=sum/5000
    e_amali.update({p:e_amal})
    e_theor=n*p/100
    e_theory.update({p:e_theor})
    var_amal=np.var(bino)
    var_amali.update({p:var_amal})
    var_theor=n*p/100*(1-(p/100))
    var_theory.update({p:var_theor})
    
for key in e_amali:
    list_e_amali.append(e_amali[key])
for key in e_theory:
    list_e_theory.append(e_theory[key])
for key in var_amali:
    list_var_amali.append(var_amali[key])
for key in var_theory:
    list_var_theory.append(var_theory[key])
    
xpoints = np.arange(100)
ypoints_e_amali = np.array(list_e_amali)
plt.plot(xpoints, ypoints_e_amali , color ='b')

ypoints_e_theory = np.array(list_e_theory)
plt.plot(xpoints, ypoints_e_theory, color='r', linestyle ='dashed')
plt.xlabel('P')
plt.ylabel('E[P]')
plt.show()

ypoints_var_amali = np.array(list_var_amali)
plt.plot(xpoints, ypoints_var_amali , color ='orange')

ypoints_var_theory = np.array(list_var_theory)
plt.plot(xpoints, ypoints_var_theory, color='yellow', linestyle ='dashed')
plt.xlabel('P')
plt.ylabel('Var[P]')
plt.show()