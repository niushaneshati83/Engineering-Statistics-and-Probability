from scipy.stats import poisson,binom,norm
import numpy as np
import matplotlib.pyplot as plt
import math 
p = 0.45
n=7072
x=range(2800,3600)
m=n*p
sigma=math.sqrt(m*(1-p))
y_poisson=poisson.pmf(x,m)
y_log=np.log(y_poisson)
plt.plot(x, y_poisson,color='red' ,linestyle ='dashed')
y_binomial = binom.pmf(x,n,p)
plt.plot(x, y_binomial,color='b')
y_normal=norm.pdf(x,m,sigma)
plt.plot(x, y_normal,color='yellow',linestyle ='dashed')
plt.xlabel('K')
plt.ylabel('P{X=K}')
plt.show()