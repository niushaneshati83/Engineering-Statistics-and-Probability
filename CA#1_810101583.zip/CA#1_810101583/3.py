from scipy.stats import poisson,binom,norm
import numpy as np
import math 
fi={}
enheraf_meiar=12
miangin=80
answer = 0
for i in range(80,116):
    x=((i-miangin)/enheraf_meiar)
    if norm.cdf(x)>0.9:
        answer=i
        break
print(answer)
for j in range(44,116):
    x=((j-miangin)/enheraf_meiar)
    if norm.cdf(x)>=0.75:
        print(j)
        break
for k in range(44,116):
    x=((k-miangin)/enheraf_meiar)
    if norm.cdf(x)>=0.5:
        print(k)
        break
m=norm.cdf((90-miangin)/enheraf_meiar)-norm.cdf((80-miangin)/enheraf_meiar)
print(m)