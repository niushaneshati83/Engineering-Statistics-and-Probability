import pandas as pd
from hazm import *
import string  
import math
from collections import defaultdict
lemmatizer = Lemmatizer()
stemmer = Stemmer()
normalizer = Normalizer()
kasb_kar=[]
kasb_kar_array=[]
kasb_kar_mid={}
unique_kasb_kar={}
roman=[]
roman_array=[]
roman_mid={}
unique_roman={}
eslam=[]
eslam_array=[]
eslam_mid={}
unique_eslam={}
jame_shenasi=[]
jame_shenasi_array=[]
jame_shenasi_mid={}
unique_jame={}
koodak_nojavan=[]
koodak_nojavan_array=[]
koodak_nojavan_mid={}
unique_koodak={}
dastan_kootah=[]
dastan_kootah_array=[]
dastan_kootah_mid={}
unique_kootah={}
def pish_pardazesh(description,categories):
        if description[0]=="۰" or description[0]=="۱" or description[0]=="۲" or description[0]=="۳" or description[0]=="۴" or description[0]=="۵" or description[0]=="۶" or description[0]=="۷" or description[0]=="۸" or description[0]=="۹" or description[0].isdigit()==True:
            description= " "
        if description[0] in string.punctuation or description[0]=="«" or description[0]=="»" or description[0]=="،" or description[0]=="…":
            description=" "
        return description
   
def remove_space(BOW):
    new_BOW=[]
    for ele in BOW:
        if ele.strip():
            new_BOW.append(ele)
    return new_BOW
    
def pish_pardazesh2(BOW):
    for x in range(len(BOW)):
        BOW[x]=lemmatizer.lemmatize(BOW[x])  
        BOW[x]=stemmer.stem(BOW[x])
    return BOW
       
def check_sw(BOW,word):
    new_BOW=[]
    for x in range(len(word)):
        for y in range(len(BOW)):
            if word[x]==BOW[y]:
                new_BOW.append(BOW[y])
    res = [i for i in BOW if i not in new_BOW]
    return res

def check_categories(categories,BOW):
    if categories=="جامعه‌شناسی":
        for x in range(len(BOW)):
            jame_shenasi.append(BOW[x])

    if categories=="کلیات اسلام":
        for x in range(len(BOW)):
                eslam.append(BOW[x])
        
    if categories=="داستان کودک و نوجوانان":
        for x in range(len(BOW)):
            koodak_nojavan.append(BOW[x])
        
    if categories=="داستان کوتاه":
        for x in range(len(BOW)):
            dastan_kootah.append(BOW[x])

    if categories=="مدیریت و کسب و کار":
        for x in range(len(BOW)):
            kasb_kar.append(BOW[x])

    if categories=="رمان":
        for x in range(len(BOW)):
            roman.append(BOW[x])

def countX(lst, x):
    count = 0
    for ele in lst:
        if (ele == x):
            count = count + 1
    return count


def check_array(categories):
    if categories=="جامعه‌شناسی":
        for x in range(len(jame_shenasi)):
            tekrar=countX(jame_shenasi,jame_shenasi[x])
            jame_shenasi_array.append((jame_shenasi[x],tekrar))
    if categories=="کلیات اسلام":
        for x in range(len(eslam)):
            tekrar=countX(eslam,eslam[x])
            eslam_array.append((eslam[x],tekrar))
    if categories=="داستان کودک و نوجوانان":
        for x in range(len(koodak_nojavan)):
            tekrar=countX(koodak_nojavan,koodak_nojavan[x])
            koodak_nojavan_array.append((koodak_nojavan[x],tekrar))
    if categories=="داستان کوتاه":
        for x in range(len(dastan_kootah)):
            tekrar=countX(dastan_kootah,dastan_kootah[x])
            dastan_kootah_array.append((dastan_kootah[x],tekrar))
    if categories=="مدیریت و کسب و کار":
        for x in range(len(kasb_kar)):
            tekrar=countX(kasb_kar,kasb_kar[x])
            kasb_kar_array.append((kasb_kar[x],tekrar))
    if categories=="رمان":
        for x in range(len(roman)):
            tekrar=countX(roman,roman[x])
            roman_array.append((roman[x],tekrar))
    

def check_element(categories):
    if categories=="جامعه‌شناسی":
        for x in range(len(jame_shenasi_array)):
            if x in jame_shenasi_mid:
                pass
            else:
                jame_shenasi_mid.update({jame_shenasi_array[x][0] : jame_shenasi_array[x][1]})
            
    if categories=="کلیات اسلام":
        for x in range(len(eslam_array)):
            if x in eslam_mid:
             pass
            else:
                eslam_mid.update({eslam_array[x][0] : eslam_array[x][1]})
    if categories=="داستان کودک و نوجوانان":
        for x in range(len(koodak_nojavan_array)):
            if x in koodak_nojavan_mid:
             pass
            else:
                koodak_nojavan_mid.update({koodak_nojavan_array[x][0] : koodak_nojavan_array[x][1]})
    if categories=="داستان کوتاه":
        for x in range(len(dastan_kootah_array)):
            if x in dastan_kootah_mid:
             pass
            else:
                dastan_kootah_mid.update({dastan_kootah_array[x][0] : dastan_kootah_array[x][1]})
    if categories=="مدیریت و کسب و کار":
        for x in range(len(kasb_kar_array)):
            if x in kasb_kar_mid:
             pass
            else:
                kasb_kar_mid.update({kasb_kar_array[x][0] : kasb_kar_array[x][1]})
    if categories=="رمان":
        for x in range(len(roman_array)):
            if x in roman_mid:
             pass
            else:
                roman_mid.update({roman_array[x][0] : roman_array[x][1]})

def pop_array():
        jame_shenasi_mid={}
        kasb_kar_mid={}
        dastan_kootah_mid={}
        koodak_nojavan_mid={}
        roman_mid={}
        eslam_mid={}
data = pd.read_csv('books_train.csv')
data2=pd.read_csv('sw.csv')
for x in range(2550):
    print(x)
    categories=data['categories'].tolist()[x]
    description=data['description'].tolist()[x]
    word=data2['word'].tolist()
    description=normalizer.normalize(description)
    new_description=word_tokenize(description)
    BOW = []
    for x in range(len(new_description)):
       BOW.append(pish_pardazesh(new_description[x],categories))
    new_BOW=[]
    new_BOW=remove_space(BOW)
    new_BOW2=[]
    new_BOW2=pish_pardazesh2(new_BOW)
    new_BOW3=[]
    new_BOW3=check_sw(new_BOW2,word)
    check_categories(categories,new_BOW3)
    check_array(categories)
    check_element(categories)
    for key in jame_shenasi_mid:
        unique_jame.update({key : jame_shenasi_mid[key]})
    for key in eslam_mid:
        unique_eslam.update({key : eslam_mid[key]})
    unique_kasb_kar=kasb_kar_mid
    for key in kasb_kar_mid:
        unique_kasb_kar.update({key : kasb_kar_mid[key]})
    for key in koodak_nojavan_mid:
        unique_koodak.update({key : koodak_nojavan_mid[key]})
    unique_kootah=dastan_kootah_mid
    for key in dastan_kootah_mid:
        unique_kootah.update({key : dastan_kootah_mid[key]})
    for key in roman_mid:
        unique_roman.update({key : roman_mid[key]})
    pop_array()
data3=pd.read_csv('books_test.csv')
for y in range(450):
    categories2=data3['categories'].tolist()[y]
    description2=data3['description'].tolist()[y]
    title=data3['title'].tolist()[y]
    description2=normalizer.normalize(description2)
    new_description2=word_tokenize(description2)
    BOW_test= []
    for e in range(len(new_description2)):
       BOW_test.append(pish_pardazesh(new_description2[e],categories2))
    new_BOW_test=[]
    new_BOW_test=remove_space(BOW_test)
    new_BOW2_test=[]
    new_BOW2_test=pish_pardazesh2(new_BOW_test)
    new_BOW3_test=[]
    new_BOW3_test=check_sw(new_BOW2_test,word)
    p_jame =1
    p_eslam = 1
    p_koodak=1 
    p_kar = 1
    p_kootah = 1
    p_roman = 1
    flag_jame=0
    flag_eslam=0
    flag_koodak = 0
    flag_kar = 0
    flag_kootah = 0
    flag_roman =0 
    for x in range(len(new_BOW3_test)):
        for key in unique_jame:
            if new_BOW3_test[x]==key:
                flag_jame=1
                p_jame = (( unique_jame[key] + 1) / (len(jame_shenasi) + len(new_description2)))* p_jame
        if flag_jame !=1 :
            p_jame = (1/(len(jame_shenasi) + len(unique_jame))) * p_jame
            flag_jame=0
        for key in unique_eslam: 
            if new_BOW3_test[x]==key:
                flag_eslam=1
                p_eslam = ((unique_eslam[key] + 1) / (len(eslam) + len(new_description2))) *p_eslam
        
        if flag_eslam !=1 :
            p_eslam = (1/(len(eslam) + len(unique_eslam))) *p_eslam
            flag_eslam = 0
        for key in unique_koodak: 
            if new_BOW3_test[x]==key:
                flag_koodak=1
                p_koodak = ((unique_koodak[key] + 1)/ ( len(koodak_nojavan) + len(new_description2)))*p_koodak
                
        if flag_koodak !=1 :
            p_koodak = (1/(len(koodak_nojavan) + len(unique_koodak))) * p_koodak
            flag_koodak=0
            
        for key in unique_kasb_kar: 
            if new_BOW3_test[x]==key:
                flag_kar=1
                p_kar = ((unique_kasb_kar[key] + 1) / (len(kasb_kar) + len(new_description2)))*p_kar
               
        if flag_kar !=1 :
            p_kar = (1/(len(kasb_kar) + len(unique_kasb_kar)))*p_kar
            flag_kar = 0
            
        for key in unique_kootah: 
            if new_BOW3_test[x]==key:
                flag_kootah=1
                p_kootah = (( unique_kootah[key] + 1)/ (len(dastan_kootah) + len(new_description2)))*p_kootah
        if flag_kootah !=1 :
            p_kootah = (1/(len(dastan_kootah) + len(unique_kootah)))*p_kootah
            flag_kootah =0 
            
        for key in unique_roman: 
            if new_BOW3_test[x]==key:
                flag_roman=1
                p_roman =((unique_roman[key] + 1) / (len(roman) + len(new_description2)))*p_roman
               
        if flag_roman !=1 :
            p_roman =(1/(len(roman) + len(unique_roman))) *p_roman
            flag_roman=0
    true_books=0
    min_=min(p_eslam,p_jame,p_kar,p_koodak,p_kootah,p_roman)
    if min_==p_jame:
        if categories2=="جامعه‌شناسی":
            true_books = true_books +1
    if min_==p_eslam:
        if categories2=="کلیات اسلام":
            true_books = true_books +1
    if min_==p_koodak:
        if categories2=="داستان کودک و نوجوانان":
            true_books = true_books+ 1
    if min_ == p_kootah:
        if categories2=="داستان کوتاه":
            true_books = true_books+ 1
    if min_ ==p_kar:
        if categories2=="مدیریت و کسب و کار":
            true_books = true_books+ 1
    if min_ ==p_roman:
        if categories=="رمان":
            true_books = true_books+ 1

print((true_books/450)*1000)
        


