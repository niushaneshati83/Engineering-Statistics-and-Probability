import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
df = pd.read_csv('Tarbiat.csv')
plt.hist(df)
 
# Adding labels and title
plt.xlabel('Values')
plt.ylabel('Frequency')
plt.title('Basic Histogram')
 
# Display the plot
plt.show()