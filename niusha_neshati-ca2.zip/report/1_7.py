from scipy.stats import binom
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from pandas import *

df = pd.read_csv('Tarbiat.csv')
landa_metro = 0
for i in range(10000):
    landa_metro= landa_metro+(df['metro'][i])
landa_metro = landa_metro/10001
print(landa_metro)
landa_brt=0
for i in range(10000):
    landa_brt= landa_brt+(df['BRT'][i])
landa_brt = landa_brt/10001
n=8
p=landa_metro/(landa_metro+landa_brt)
k=range(0,9)
w=binom.pmf(k,n,p)
hist=plt.bar(k,w)
plt.show()