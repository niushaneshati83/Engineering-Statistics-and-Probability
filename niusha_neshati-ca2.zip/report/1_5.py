import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as sp
df = pd.read_csv('Tarbiat.csv')
z=[]
for i in range(10000):
    z.append(df['metro'][i]+df['BRT'][i])
plt.hist(z,density=True)
plt.title('Histogram')
plt.xlabel('pass subway')
plt.ylabel('metro')
plt.show()