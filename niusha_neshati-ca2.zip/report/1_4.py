import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as sp
df = pd.read_csv('Tarbiat.csv')
plt.hist(df['metro'],density=True)
X_dist = sp.poisson(mu=3.5312468753124686)
x_ = np.arange(0, 12, 1)
y_ = sp.poisson.pmf(x_, mu=3.5312468753124686)
plt.plot(x_, y_)
plt.show()