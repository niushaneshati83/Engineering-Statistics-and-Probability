import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as sp
df = pd.read_csv('Tarbiat.csv')
plt.hist(df['metro'],density=True)
plt.show()