import random
def monte_carlo(n,k):
    counter=[]
    for i in range(k):
        my_dict=[0 for j in range(n)]
        count=0
        while my_dict.count(1) <n:
            my_dict[random.randint(0,n-1)]=1
            count=count+1
        counter.append(count)
    return sum(counter) / k
n=input()
k=input()
print(monte_carlo(int(n),int(k)))