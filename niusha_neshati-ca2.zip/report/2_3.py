import sympy
s = sympy.symbols('s')
n=10
mgf_kol=1
mgf = []
for i in range(1,n):
    p = i/10
    mgf.append( [(p * sympy.exp(s)) / (1 - ((1-p) * sympy.exp(s))) ])
    #part4
print(mgf[2])
for j in range(n):
   mgf_kol *= mgf[j]